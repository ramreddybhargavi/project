import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useTasks } from '../context/TaskContext';

export default function TaskForm() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = Boolean(id);

  const { getTaskById, createTask, updateTask } = useTasks();

  const [form, setForm] = useState({
    title: '',
    description: '',
    completed: false,
  });

  useEffect(() => {
    if (isEdit) {
      const task = getTaskById(id);
      if (task) {
        setForm({
          title: task.title,
          description: task.description || '',
          completed: task.completed,
        });
      }
    }
  }, [id, isEdit, getTaskById]);

  const onChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm((f) => ({ ...f, [name]: type === 'checkbox' ? checked : value }));
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    if (isEdit) {
      await updateTask(id, form);
    } else {
      await createTask(form);
    }
    navigate('/tasks');
  };

  return (
    <form onSubmit={onSubmit} style={{ maxWidth: 600, margin: '40px auto', display: 'flex', flexDirection: 'column', gap: 12 }}>
      <h2>{isEdit ? 'Edit Task' : 'New Task'}</h2>

      <label>
        Title
        <input name="title" value={form.title} onChange={onChange} required />
      </label>

      <label>
        Description
        <textarea name="description" value={form.description} onChange={onChange} />
      </label>

      <label>
        <input
          type="checkbox"
          name="completed"
          checked={form.completed}
          onChange={onChange}
        /> Completed
      </label>

      <div style={{ display: 'flex', gap: 8 }}>
        <button type="submit">{isEdit ? 'Save' : 'Create'}</button>
        <button type="button" onClick={() => navigate('/tasks')}>Cancel</button>
      </div>
    </form>
  );
}
