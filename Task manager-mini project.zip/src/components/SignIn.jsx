import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

export default function SignIn() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const onChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const onSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await login(form.email, form.password);
      navigate('/tasks');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={onSubmit} style={{ maxWidth: 360, margin: '60px auto', display:'flex', flexDirection:'column', gap:12}}>
      <h2>Sign in</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <label>Email <input name="email" type="email" value={form.email} onChange={onChange} required /></label>
      <label>Password <input name="password" type="password" value={form.password} onChange={onChange} required /></label>
      <button disabled={loading}>{loading ? 'Signing in...' : 'Sign in'}</button>
    </form>
  );
}
