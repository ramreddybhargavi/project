import { useTasks } from '../context/TaskContext';
import { useAuth } from '../context/AuthContext';
import { Link, useNavigate } from 'react-router-dom';

export default function TaskList() {
  const { items, loading, error, deleteTask, updateTask, createTask } = useTasks();
  const { logout } = useAuth();
  const navigate = useNavigate();

  if (loading) return <p style={{ padding: 20 }}>Loading…</p>;
  if (error) return <p style={{ padding: 20, color: 'red' }}>{error}</p>;

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: 24 }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 24 }}>
        <h2>Task Manager</h2>
        <button onClick={logout}>Logout</button>
      </header>

      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        <button onClick={() => navigate('/tasks/new')}>+ New Task</button>
        <button onClick={() => createTask({ title:'Sample Task', description:'Example', completed:false })}>+ Sample Task</button>
      </div>

      {items.length === 0 && <p>No tasks yet.</p>}
      <ul style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {items.map((t) => (
          <li key={t.id} style={{ border: '1px solid #ddd', padding: 12 }}>
            <strong>{t.title}</strong> {t.completed ? '✅' : '❌'}
            {t.description && <p style={{ marginTop: 6 }}>{t.description}</p>}
            <div style={{ marginTop: 8, display: 'flex', gap: 8 }}>
              <button onClick={() => updateTask(t.id, { completed: !t.completed })}>Toggle</button>
              <button onClick={() => deleteTask(t.id)}>Delete</button>
              <Link to={`/tasks/${t.id}/edit`}>Edit</Link>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
