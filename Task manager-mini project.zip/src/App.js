import { Routes, Route, Navigate } from 'react-router-dom';
import SignIn from './components/SignIn';
import TaskList from './components/TaskList';
import ProtectedRoute from './components/ProtectedRoute';
import TaskForm from './components/TaskForm';

export default function App() {
  return (
    <Routes>
      <Route path="/signin" element={<SignIn />} />

      <Route
        path="/tasks"
        element={
          <ProtectedRoute>
            <TaskList />
          </ProtectedRoute>
        }
      />

      <Route
        path="/tasks/new"
        element={
          <ProtectedRoute>
            <TaskForm />
          </ProtectedRoute>
        }
      />

      <Route
        path="/tasks/:id/edit"
        element={
          <ProtectedRoute>
            <TaskForm />
          </ProtectedRoute>
        }
      />

      <Route path="/" element={<Navigate to="/signin" replace />} />
      <Route path="*" element={<Navigate to="/signin" replace />} />
    </Routes>
  );
}
