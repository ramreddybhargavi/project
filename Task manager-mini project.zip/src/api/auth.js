const STORAGE_KEY = 'tm_user';

export async function login(email, password) {
  await new Promise((res) => setTimeout(res, 300));
  if (!email || !password) throw new Error('Email & password required');
  const user = { id: '1', email, token: 'fake-jwt-token' };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
  return user;
}

export function logout() {
  localStorage.removeItem(STORAGE_KEY);
}

export function getStoredUser() {
  const raw = localStorage.getItem(STORAGE_KEY);
  return raw ? JSON.parse(raw) : null;
}
