const STORAGE_KEY = 'tm_tasks';

function read() {
  const raw = localStorage.getItem(STORAGE_KEY);
  return raw ? JSON.parse(raw) : [];
}

function write(data) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

function delay(ms = 150) {
  return new Promise((r) => setTimeout(r, ms));
}

export async function getAll() {
  await delay();
  return read();
}

export async function create(payload) {
  await delay();
  const tasks = read();
  const task = {
    id: crypto.randomUUID(),
    title: payload.title,
    description: payload.description || '',
    completed: !!payload.completed,
    createdAt: new Date().toISOString(),
  };
  tasks.unshift(task);
  write(tasks);
  return task;
}

export async function update(id, payload) {
  await delay();
  const tasks = read();
  const index = tasks.findIndex((t) => t.id === id);
  if (index === -1) throw new Error('Task not found');
  const updated = { ...tasks[index], ...payload };
  tasks[index] = updated;
  write(tasks);
  return updated;
}

export async function remove(id) {
  await delay();
  const tasks = read();
  write(tasks.filter((t) => t.id !== id));
  return true;
}
