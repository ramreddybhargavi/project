import { createContext, useContext, useEffect, useReducer } from 'react';
import * as tasksApi from '../api/tasks';

const TaskContext = createContext(null);

const initialState = { loading: false, error: null, items: [] };

function reducer(state, action) {
  switch (action.type) {
    case 'LOAD_START':
      return { ...state, loading: true, error: null };
    case 'LOAD_SUCCESS':
      return { ...state, loading: false, items: action.payload };
    case 'ERROR':
      return { ...state, loading: false, error: action.payload };
    case 'ADD':
      return { ...state, items: [action.payload, ...state.items] };
    case 'UPDATE':
      return { ...state, items: state.items.map(t => t.id === action.payload.id ? action.payload : t) };
    case 'DELETE':
      return { ...state, items: state.items.filter(t => t.id !== action.payload) };
    default:
      return state;
  }
}

export function TaskProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  const loadTasks = async () => {
    dispatch({ type: 'LOAD_START' });
    try {
      const data = await tasksApi.getAll();
      dispatch({ type: 'LOAD_SUCCESS', payload: data });
    } catch (e) {
      dispatch({ type: 'ERROR', payload: e.message });
    }
  };

  const createTask = async (payload) => {
    const task = await tasksApi.create(payload);
    dispatch({ type: 'ADD', payload: task });
    return task;
  };

  const updateTask = async (id, payload) => {
    const task = await tasksApi.update(id, payload);
    dispatch({ type: 'UPDATE', payload: task });
    return task;
  };

  const deleteTask = async (id) => {
    await tasksApi.remove(id);
    dispatch({ type: 'DELETE', payload: id });
  };

  const getTaskById = (id) => state.items.find(t => t.id === id);

  useEffect(() => { loadTasks(); }, []);

  return (
    <TaskContext.Provider value={{ ...state, loadTasks, createTask, updateTask, deleteTask, getTaskById }}>
      {children}
    </TaskContext.Provider>
  );
}

export const useTasks = () => useContext(TaskContext);
